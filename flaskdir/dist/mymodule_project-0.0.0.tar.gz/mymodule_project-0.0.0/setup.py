import os
from distutils.core import setup, Extension

module1 = Extension ('mymodule', sources = ['mymodule.c'])

setup(
    name = "mymodule_project",
    version = "0.0.0",
    description = ("An demonstration of building my module "),
    ext_modules = [module1]
)
